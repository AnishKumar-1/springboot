package facebookApi.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import facebookApi.Models.Users;
import facebookApi.Security.TokenResponse;
import facebookApi.Services.UserService;
import jakarta.servlet.http.HttpServletRequest;



@RestController
@RequestMapping("/api/v1/")
public class UserController {

	
	@Autowired 
	private UserService userService;
	
	 @PostMapping("/login")
	    public ResponseEntity<TokenResponse> userLogin(@RequestBody Users user) {
	        return new ResponseEntity<>(userService.login(user), HttpStatus.OK);
	    }

	 @PostMapping("/refresh")
	 public ResponseEntity<String> refreshAccessToken(HttpServletRequest request) {
	     String authorizationHeader = request.getHeader("Authorization");
	     if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
	         String refreshToken = authorizationHeader.substring(7);
	         return new ResponseEntity<>(userService.refreshAccessToken(refreshToken), HttpStatus.OK);
	     } else {
	         throw new IllegalArgumentException("Token is missing or improperly formatted");
	     }
	 }

	    
	    
	
	@GetMapping("/user")
	@PreAuthorize("hasRole('USER')")
	public String test() {
		return "hello user";
	}
}
	