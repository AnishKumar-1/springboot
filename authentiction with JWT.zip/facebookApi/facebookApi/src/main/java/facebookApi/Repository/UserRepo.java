package facebookApi.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import facebookApi.Models.Users;

public interface UserRepo extends JpaRepository<Users, Long>{
	 public Users findByEmail(String email);
	}
