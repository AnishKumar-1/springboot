package facebookApi.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import facebookApi.Models.Role;


public interface RoleRepo extends JpaRepository<Role, Long>{

}
