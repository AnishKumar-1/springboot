package facebookApi.Security;

import java.security.Key;
import java.util.Date;
import java.util.function.Function;

import javax.crypto.SecretKey;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;



@Component
public class JwtHelper {

	//generate token we need encrypted key and expiration time in ms
    private final String SECRET_KEY="15291f67d99ea7bc578c3544dadfbb991e66fa69cb36ff70fe30e798e111ff5f";
    private long accessExpirationTime=1*60*1000;
    private final long refreshExpirationTime=30*60*1000; // 30 minutes for refresh token
    //secret key encoded with hs256 bits
//    private final SecretKey secretKey=Keys.hmacShaKeyFor(SECRET_KEY.getBytes());
    
 
    
    //method to decode the key for further user
    public Key getKey() {
    	return Keys.hmacShaKeyFor(Decoders.BASE64.decode(SECRET_KEY));
    }
    
    public String tokenGenerate(Authentication authentication,long expirationTime) {
    	String username=authentication.getName();
    	Date now = new Date();
        Date expiryDate = new Date(now.getTime() + expirationTime);
    	  return Jwts.builder()
    			  .header().empty().add("typ","JWT")
    			  .and()
                 .subject(username).issuedAt(new Date())
                 .expiration(expiryDate)
                 .signWith(getKey())
                 .compact();
    }
    public String generateAccessToken(Authentication authentication) {
        return tokenGenerate(authentication, accessExpirationTime);
    }

    public String generateRefreshToken(Authentication authentication) {
        return tokenGenerate(authentication, refreshExpirationTime);
    }

    //validate token
    public boolean tokenIsValid(String token) {
    	try {
    		Jwts.parser().verifyWith((SecretKey) getKey())
    		.build().parse(token);
    		return true;
 
    	}catch (ExpiredJwtException ex) {
    		System.out.print("exception expired class called");
            throw new ExpiredJwtException(null, null, "Token is expired");
        } catch (MalformedJwtException ex) {
            throw new MalformedJwtException("Token is malformed");
        }catch (UnsupportedJwtException ex) {
         throw new UnsupportedJwtException("Unsupported token");
        }catch (IllegalArgumentException ex) {
          throw new IllegalArgumentException("Token is null or empty");
        } catch (Exception ex) {
            throw new RuntimeException("Invalid Token");
        }
    }
   
    //method to get claims
    public Claims extractAllClaims(String token) {
    	 return Jwts.parser().verifyWith((SecretKey) getKey())
    			 .build()
    			 .parseSignedClaims(token)
    			 .getPayload();
    }
    //method to get perticular claims
    public <T> T extractClamins(String token,Function<Claims,T>claimResolver) {
       return claimResolver.apply(extractAllClaims(token));
    }
    //get username(subject) from claims
    public String extractUsername(String token) {
    	return extractClamins(token,Claims::getSubject);
    }
    
    //check token is expired or not
    public boolean isTokenExpired(String token) {
    	return extractClamins(token,Claims::getExpiration).before(new Date());
    }
 
}

