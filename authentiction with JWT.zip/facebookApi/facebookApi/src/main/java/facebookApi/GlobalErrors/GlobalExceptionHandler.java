package facebookApi.GlobalErrors;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import jakarta.servlet.http.HttpServletRequest;

@RestControllerAdvice
public class GlobalExceptionHandler{
	   private final SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	   @ExceptionHandler(UsernameNotFoundException.class)
	    public ResponseEntity<CustomError> handleUsernameNotFoundException(UsernameNotFoundException ex, HttpServletRequest request) {
	        CustomError customError = new CustomError();
	        customError.setError(ex.getMessage());
	        customError.setPath(request.getRequestURI());
	        customError.setTimestamp(simpleDateFormat.format(new Date()));
	        return new ResponseEntity<>(customError, HttpStatus.NOT_FOUND);
	    }

	    @ExceptionHandler(AccessDeniedException.class)
	    public ResponseEntity<CustomError> handleAccessDeniedException(AccessDeniedException ex, HttpServletRequest request) {
	        CustomError customError = new CustomError();
	        customError.setError(ex.getMessage());
	        customError.setPath(request.getRequestURI());
	        customError.setTimestamp(simpleDateFormat.format(new Date()));
	        return new ResponseEntity<>(customError, HttpStatus.FORBIDDEN);
	    }

	    @ExceptionHandler(IllegalArgumentException.class)
	    public ResponseEntity<CustomError> handleIllegalArgumentException(IllegalArgumentException ex, HttpServletRequest request) {
	        CustomError customError = new CustomError();
	        customError.setError(ex.getMessage());
	        customError.setPath(request.getRequestURI());
	        customError.setTimestamp(simpleDateFormat.format(new Date()));
	        return new ResponseEntity<>(customError, HttpStatus.BAD_REQUEST);
	    }

	    @ExceptionHandler(ExpiredJwtException.class)
	    public ResponseEntity<CustomError> handleExpiredJwtException(ExpiredJwtException ex, HttpServletRequest request) {
	        CustomError customError = new CustomError();
	        customError.setError(ex.getMessage());
	        customError.setPath(request.getRequestURI());
	        customError.setTimestamp(simpleDateFormat.format(new Date()));
	        return new ResponseEntity<>(customError, HttpStatus.UNAUTHORIZED);
	    }

	    @ExceptionHandler(MalformedJwtException.class)
	    public ResponseEntity<CustomError> handleMalformedJwtException(MalformedJwtException ex, HttpServletRequest request) {
	        CustomError customError = new CustomError();
	        customError.setError(ex.getMessage());
	        customError.setPath(request.getRequestURI());
	        customError.setTimestamp(simpleDateFormat.format(new Date()));
	        return new ResponseEntity<>(customError, HttpStatus.BAD_REQUEST);
	    }

	    @ExceptionHandler(UnsupportedJwtException.class)
	    public ResponseEntity<CustomError> handleUnsupportedJwtException(UnsupportedJwtException ex, HttpServletRequest request) {
	        CustomError customError = new CustomError();
	        customError.setError(ex.getMessage());
	        customError.setPath(request.getRequestURI());
	        customError.setTimestamp(simpleDateFormat.format(new Date()));
	        return new ResponseEntity<>(customError, HttpStatus.BAD_REQUEST);
	    }

	    @ExceptionHandler(RuntimeException.class)
	    public ResponseEntity<CustomError> handleRuntimeException(RuntimeException ex, HttpServletRequest request) {
	        CustomError customError = new CustomError();
	        customError.setError(ex.getMessage());
	        customError.setPath(request.getRequestURI());
	        customError.setTimestamp(simpleDateFormat.format(new Date()));
	        return new ResponseEntity<>(customError, HttpStatus.UNAUTHORIZED);
	    }

	    @ExceptionHandler(Exception.class)
	    public ResponseEntity<CustomError> handleUnexpectedException(Exception ex, HttpServletRequest request) {
	        CustomError customError = new CustomError();
	        customError.setError(ex.getMessage());
	        customError.setPath(request.getRequestURI());
	        customError.setTimestamp(simpleDateFormat.format(new Date()));
	        return new ResponseEntity<>(customError, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}
