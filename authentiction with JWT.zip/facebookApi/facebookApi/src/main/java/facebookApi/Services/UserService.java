package facebookApi.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import facebookApi.Models.Users;
import facebookApi.Security.CustomUserDetailService;
import facebookApi.Security.JwtHelper;
import facebookApi.Security.TokenResponse;



@Service
public class UserService {

	@Autowired
	private AuthenticationManager authenticationManager;
	@Autowired
	CustomUserDetailService customUserDetailService;
	@Autowired
	private JwtHelper jwtHelper;
	
    public TokenResponse login(Users user) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword())
            );

            SecurityContextHolder.getContext().setAuthentication(authentication);
            String accessToken = jwtHelper.generateAccessToken(authentication);
            String refreshToken = jwtHelper.generateRefreshToken(authentication);
            return new TokenResponse(accessToken, refreshToken);
        } catch (Exception ex) {
            throw new UsernameNotFoundException("Bad Credential", ex);
        }
    }

    public String refreshAccessToken(String refreshToken) {
        if (jwtHelper.tokenIsValid(refreshToken) && !jwtHelper.isTokenExpired(refreshToken)) {
            String username = jwtHelper.extractUsername(refreshToken);
            UserDetails userDetails = customUserDetailService.loadUserByUsername(username);
            Authentication authentication = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
            return jwtHelper.generateAccessToken(authentication);
        } else {
            throw new IllegalArgumentException("Invalid or expired refresh token");
        }
    }
}
