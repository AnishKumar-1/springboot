insert into Role(role) values('ROLE_USER'),('ROLE_ADMIN');

insert into Users(email,password,user_role)
values('anish123@gmail.com','$2a$12$W9yqdY2Ws0wUoyWldXHgrumXz47h169BUZExFaFgz.9o704MHDK2a',1),
('rohit.manager123@gmai.com','$2a$12$F2xND9WeDT19b3PUeyIUwOZRUh2C5YTvh.Zgv2R5.B9BRaTTQnnkW',2);

